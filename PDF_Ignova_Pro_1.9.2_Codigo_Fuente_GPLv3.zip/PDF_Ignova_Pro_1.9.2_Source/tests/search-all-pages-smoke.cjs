const assert = require("node:assert/strict");
const fs = require("node:fs");
const path = require("node:path");

const source = fs.readFileSync(
  path.join(__dirname, "..", "app", "editor-assets", "editor-entry.js"),
  "utf8",
);

assert.match(source, /pages = \[\.\.\.o\.current\]/);
assert.match(source, /pageNumber >= pages\.length/);
assert.match(source, /getPage\(pageReference\.index \+ 1\)/);
assert.match(source, /Ta\(firstResult\.pageId\)/);
assert.match(source, /Buscar en todas las p\\xE1ginas/);
assert.match(source, /buildPageSearchMatches/);
assert.match(source, /SearchHighlightLayer/);
assert.match(source, /goToSearchResult/);
assert.match(source, /search-hit\.current/);
assert.match(source, /currentSearchIndex \+ 1/);
