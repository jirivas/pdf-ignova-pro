const assert = require("node:assert/strict");
const fs = require("node:fs/promises");
const Module = require("node:module");
const os = require("node:os");
const path = require("node:path");

async function main() {
  const userData = await fs.mkdtemp(path.join(os.tmpdir(), "pdf-ignova-license-test-"));
  const dialogCalls = [];
  const electronMock = {
    app: { getPath: () => userData },
    clipboard: { writeText: () => {} },
    dialog: {
      showMessageBox: async (...args) => {
        dialogCalls.push(args);
        return { response: 0 };
      },
      showOpenDialog: async () => ({ canceled: true, filePaths: [] }),
    },
  };

  const originalLoad = Module._load;
  Module._load = function patchedLoad(request, parent, isMain) {
    if (request === "electron") return electronMock;
    return originalLoad.call(this, request, parent, isMain);
  };

  try {
    const support = require("../commercial-license.cjs");
    const firstRun = await support.initializeSupportLicense();
    assert.equal(firstRun.licensed, false);
    assert.equal(firstRun.reminderDue, false);

    const oldDate = new Date(Date.now() - 31 * 24 * 60 * 60 * 1000).toISOString();
    await fs.writeFile(
      path.join(userData, "support-reminder.json"),
      JSON.stringify({ firstRunAt: oldDate, lastReminderAt: null }),
      "utf8",
    );
    const afterThirtyDays = await support.initializeSupportLicense();
    assert.equal(afterThirtyDays.reminderDue, true);

    const continued = await support.maybeShowSupportReminder(null, afterThirtyDays);
    assert.equal(continued.licensed, false);
    assert.equal(continued.reminderDue, false);
    assert.equal(dialogCalls.length, 1);

    // A second reminder must not be due before 30 additional days.
    const shortlyAfterReminder = await support.initializeSupportLicense();
    assert.equal(shortlyAfterReminder.reminderDue, false);
    assert.equal(support.REMINDER_INTERVAL_DAYS, 30);
  } finally {
    Module._load = originalLoad;
    await fs.rm(userData, { recursive: true, force: true });
  }
}

main().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});
