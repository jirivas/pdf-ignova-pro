import assert from "node:assert/strict";
import { buildPageSearchMatches } from "../app/editor-assets/search-engine.mjs";

const viewport = {
  width: 100,
  height: 100,
  scale: 1,
  transform: [1, 0, 0, -1, 0, 100],
};

const textContent = {
  items: [
    { str: "Hola", width: 20, dir: "ltr", transform: [1, 0, 0, 10, 10, 20] },
    { str: "mundo", width: 25, dir: "ltr", transform: [1, 0, 0, 10, 35, 20] },
    { str: "Hola", width: 20, dir: "ltr", transform: [1, 0, 0, 10, 10, 40] },
  ],
};

const phrase = buildPageSearchMatches({
  textContent,
  viewport,
  query: "hola mundo",
  pageId: "page-1",
  pageNumber: 0,
});

assert.equal(phrase.length, 1);
assert.equal(phrase[0].pageId, "page-1");
assert.equal(phrase[0].pageNumber, 0);
assert.equal(phrase[0].rects.length, 2);
assert.match(phrase[0].snippet, /Hola mundo/);

const repeated = buildPageSearchMatches({
  textContent,
  viewport,
  query: "hola",
  pageId: "page-1",
  pageNumber: 0,
});

assert.equal(repeated.length, 2);
assert.ok(repeated.every((match) => match.rects.length === 1));
assert.ok(repeated[0].rects[0].w > 0);
