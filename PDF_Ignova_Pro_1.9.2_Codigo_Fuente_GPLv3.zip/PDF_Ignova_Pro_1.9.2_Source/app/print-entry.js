import {
  getDocument,
  GlobalWorkerOptions,
} from "./editor-assets/chunks/pdf-V76QT5PL.js";

GlobalWorkerOptions.workerSrc = new URL("./pdf.worker.mjs", import.meta.url).href;

const params = new URLSearchParams(location.search);
const source = params.get("source") || "";
const documentName = params.get("name") || "documento.pdf";
const statusTitle = document.getElementById("status-title");
const progress = document.getElementById("progress");
const printRoot = document.getElementById("print-root");
const closeButton = document.getElementById("close-button");
const generatedUrls = [];

window.__PDF_ESTUDIO_PRINT__ = {
  state: "loading",
  page: 0,
  total: 0,
  error: "",
};

function updateProgress(message, page = 0, total = 0) {
  progress.textContent = message;
  Object.assign(window.__PDF_ESTUDIO_PRINT__, { page, total });
}

function fail(error) {
  const message = error?.message || String(error || "Error desconocido");
  console.error("No se pudo preparar la impresión", error);
  document.body.classList.add("error");
  statusTitle.textContent = "No se pudo preparar la impresión";
  progress.textContent = `${message}. Cierra esta ventana y vuelve a intentarlo.`;
  Object.assign(window.__PDF_ESTUDIO_PRINT__, {
    state: "error",
    error: message,
  });
}

function canvasToPng(canvas) {
  return new Promise((resolve, reject) => {
    canvas.toBlob(
      blob => blob ? resolve(blob) : reject(new Error("No se pudo preparar una página")),
      "image/png",
    );
  });
}

function nextPaint() {
  return new Promise(resolve => requestAnimationFrame(() => requestAnimationFrame(resolve)));
}

function renderingScale(baseViewport, totalPages) {
  const targetDpi = totalPages <= 24 ? 144 : totalPages <= 80 ? 120 : 96;
  let scale = targetDpi / 72;
  const perPagePixelLimit = totalPages <= 24 ? 14000000 : 8000000;
  const estimatedPixels = baseViewport.width * baseViewport.height * scale * scale;
  if (estimatedPixels > perPagePixelLimit) {
    scale *= Math.sqrt(perPagePixelLimit / estimatedPixels);
  }
  const maxDimension = Math.max(baseViewport.width, baseViewport.height) * scale;
  if (maxDimension > 6500) scale *= 6500 / maxDimension;
  return Math.max(1, scale);
}

async function renderDocument() {
  const sourceUrl = new URL(source);
  if (sourceUrl.protocol !== "file:") {
    throw new Error("La ruta temporal de impresión no es válida");
  }

  document.title = `Imprimir — ${documentName}`;
  const loadingTask = getDocument({
    url: sourceUrl.href,
    disableAutoFetch: false,
    disableStream: false,
    isEvalSupported: false,
  });
  const pdf = await loadingTask.promise;
  const totalPages = pdf.numPages;
  if (!totalPages) throw new Error("El documento no contiene páginas");
  window.__PDF_ESTUDIO_PRINT__.total = totalPages;

  const pageRules = [];
  for (let pageNumber = 1; pageNumber <= totalPages; pageNumber += 1) {
    updateProgress(
      `Preparando página ${pageNumber} de ${totalPages}…`,
      pageNumber,
      totalPages,
    );

    const page = await pdf.getPage(pageNumber);
    const baseViewport = page.getViewport({ scale: 1 });
    const cssViewport = page.getViewport({ scale: 96 / 72 });
    const renderViewport = page.getViewport({
      scale: renderingScale(baseViewport, totalPages),
    });

    const canvas = document.createElement("canvas");
    canvas.width = Math.max(1, Math.ceil(renderViewport.width));
    canvas.height = Math.max(1, Math.ceil(renderViewport.height));
    const context = canvas.getContext("2d", { alpha: false });
    if (!context) throw new Error(`No se pudo representar la página ${pageNumber}`);

    await page.render({
      canvasContext: context,
      viewport: renderViewport,
      background: "rgb(255, 255, 255)",
      intent: "print",
    }).promise;

    const blob = await canvasToPng(canvas);
    const imageUrl = URL.createObjectURL(blob);
    generatedUrls.push(imageUrl);
    const image = new Image();
    image.alt = `Página ${pageNumber}`;
    image.src = imageUrl;
    await image.decode();

    const pageName = `pdf-estudio-page-${pageNumber}`;
    pageRules.push(
      `@page ${pageName} { size: ${baseViewport.width}pt ${baseViewport.height}pt; margin: 0; }`,
    );
    const sheet = document.createElement("section");
    sheet.className = "print-sheet";
    sheet.style.width = `${cssViewport.width}px`;
    sheet.style.height = `${cssViewport.height}px`;
    sheet.style.setProperty("page", pageName);
    sheet.append(image);
    printRoot.append(sheet);

    canvas.width = 1;
    canvas.height = 1;
    page.cleanup();
    await nextPaint();
  }

  const pageStyle = document.createElement("style");
  pageStyle.textContent = pageRules.join("\n");
  document.head.append(pageStyle);
  printRoot.setAttribute("aria-hidden", "false");
  updateProgress("Abriendo el cuadro de impresoras…", totalPages, totalPages);
  window.__PDF_ESTUDIO_PRINT__.state = "ready";
  await nextPaint();

  let closing = false;
  const closeAfterPrint = () => {
    if (closing) return;
    closing = true;
    for (const url of generatedUrls) URL.revokeObjectURL(url);
    setTimeout(() => window.close(), 250);
  };
  window.addEventListener("afterprint", closeAfterPrint, { once: true });
  setTimeout(() => {
    try {
      window.print();
    } catch (error) {
      fail(error);
    }
  }, 200);
}

closeButton.addEventListener("click", () => window.close());
renderDocument().catch(fail);
