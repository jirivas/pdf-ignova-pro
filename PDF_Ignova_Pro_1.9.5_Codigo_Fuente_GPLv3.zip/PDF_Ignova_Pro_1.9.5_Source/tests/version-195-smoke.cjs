"use strict";

const assert = require("node:assert/strict");
const fs = require("node:fs");
const path = require("node:path");

const root = path.resolve(__dirname, "..");
const read = relativePath => fs.readFileSync(path.join(root, relativePath), "utf8");
const packageJson = JSON.parse(read("package.json"));
const main = read("main.cjs");
const editor = read("app/editor-assets/editor-entry.js");
const html = read("app/editor.html");
const ocr = read("scripts/ocr-windows.ps1");
const installer = read("installer/PDF-Ignova-Pro.iss");

assert.equal(packageJson.version, "1.9.5");
assert.match(packageJson.scripts["package:windows"], /--asar\.unpackDir=scripts/);
assert.match(packageJson.scripts["package:windows"], /release-installer/);
assert.match(main, /app\.asar\.unpacked/);
assert.match(main, /runtime-scripts/);
assert.match(editor, /ocr-region/);
assert.match(editor, /window\.pdfEstudio\.ocrPage/);
assert.match(editor, /Nuevo PDF en blanco/);
assert.match(editor, /595\.28, 841\.89/);
assert.match(html, /i18n-extra\.js/);
assert.match(
  ocr,
  /OpenAsync\(\[Windows\.Storage\.FileAccessMode\]::Read\)\) \(\[Windows\.Storage\.Streams\.IRandomAccessStream\]\)/,
);
assert.match(installer, /Uninstallable=yes/);
assert.match(installer, /PDF-Ignova-Pro-1\.9\.5-Setup-Windows-x64-unsigned/);
assert.match(installer, /\{uninstallexe\}/);
assert.ok(fs.existsSync(path.join(root, "app", "flags", "zh.svg")));
assert.ok(fs.existsSync(path.join(root, "app", "flags", "ms.svg")));

console.log("version 1.9.5 smoke test passed");
