"use strict";

const assert = require("node:assert/strict");
const browserI18n = require("../app/editor-assets/i18n-data.js");
const { getMessages, normalizeLanguage } = require("../native-i18n.cjs");

assert.deepEqual(Object.keys(browserI18n.languages), ["es", "en", "pt", "de", "fr"]);
assert.equal(browserI18n.normalizeLanguage("pt-BR"), "pt");
assert.equal(normalizeLanguage("fr-FR"), "fr");
assert.equal(browserI18n.translate("Archivo", "en"), "File");
assert.equal(browserI18n.translate("Guardar", "de"), "Speichern");
assert.equal(browserI18n.translate("Imprimir", "fr"), "Imprimer");
assert.equal(browserI18n.translate("Página 12", "en"), "Page 12");
assert.equal(browserI18n.translate("7 coincidencias", "de"), "7 Treffer");

const sourceKeys = browserI18n.rows.map((row) => row[0]);
assert.equal(new Set(sourceKeys).size, sourceKeys.length, "Duplicate Spanish translation key");
for (const row of browserI18n.rows) {
  assert.equal(row.length, 5, `Incomplete translation row: ${row[0]}`);
  row.forEach((value) => assert.ok(String(value).trim(), `Empty translation: ${row[0]}`));
}

const requiredMenuLabels = [
  "Archivo", "Editar", "Páginas", "Visualización", "Abrir o convertir",
  "Guardar", "Guardar como", "Imprimir", "Marca de agua", "Firma digital",
  "Buscar en todas las páginas", "Propiedades", "Personalizar barra de herramientas",
];
for (const label of requiredMenuLabels) {
  assert.ok(browserI18n.canTranslate(label), `Missing interface label: ${label}`);
}

for (const language of ["es", "en", "pt", "de", "fr"]) {
  const native = getMessages(language);
  assert.match(native.print.paperDetail, /A2/);
  assert.match(native.print.paperDetail, /A1/);
  assert.ok(native.license.purchase.length > 30);
  assert.ok(native.license.thanks("Test User").includes("Test User"));
}

console.log("i18n smoke test passed");
