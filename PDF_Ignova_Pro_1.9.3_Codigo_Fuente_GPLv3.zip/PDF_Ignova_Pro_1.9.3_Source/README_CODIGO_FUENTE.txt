PDF IGNOVA PRO 1.9.3 — CÓDIGO FUENTE DISTRIBUIDO

Este paquete contiene el código JavaScript y los recursos ejecutados por la
aplicación Electron PDF Ignova Pro 1.9.3.

NOVEDADES DE ESTA VERSIÓN
La interfaz incorpora español, inglés, portugués, alemán y francés, elegibles
desde el selector superior con banderas. La selección se conserva entre usos.
La impresión permite generar y enviar documentos en tamaño original, A4, A3,
A2 y A1, con orientación automática y contenido centrado sin deformación.

LICENCIA DEL CÓDIGO PROPIO
El código propio se distribuye bajo GNU GPL versión 3 o posterior
(GPL-3.0-or-later). Los componentes de terceros conservan sus licencias.

MODELO DE APOYO
La aplicación funciona completa desde el primer día. Durante los primeros
30 días no muestra avisos. Después presenta, como máximo una vez cada 30 días,
un recordatorio discreto para adquirir una licencia permanente por equipo.
La licencia elimina el recordatorio y apoya el desarrollo de la compilación
oficial; no es una condición para ejercer los derechos concedidos por la GPL.

MARCA
La GPL cubre el código, pero no concede derechos sobre el nombre PDF Ignova
Pro, los logotipos ni otros signos distintivos. Una versión modificada no debe
presentarse como distribución oficial de IGNOVA sin autorización.

FUENTE DISPONIBLE
El árbol de desarrollo original de React no se conservó en el instalador de
partida. Este paquete ofrece el JavaScript ejecutable recuperado, legible y
modificable, junto con los recursos y scripts de escritorio. Conviene conservar
en adelante el repositorio de desarrollo anterior al empaquetado.

Copyright © 2026 José Ignacio Rivas Negreira / IGNOVA Ingeniería.
