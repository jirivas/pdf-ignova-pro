"use strict";

const assert = require("node:assert/strict");
const fs = require("node:fs");
const path = require("node:path");

const root = path.join(__dirname, "..");
const read = (relativePath) => fs.readFileSync(path.join(root, relativePath), "utf8");

const main = read("main.cjs");
const editor = read("app/editor-assets/editor-entry.js");
const html = read("app/editor.html");
const packageJson = JSON.parse(read("package.json"));

assert.equal(packageJson.version, "1.9.4");
assert.match(packageJson.scripts["package:windows"], /--asar\.unpackDir=scripts/);
assert.match(main, /app\.asar\.unpacked/);
assert.match(main, /runtime-scripts/);
assert.match(editor, /ocr-region/);
assert.match(editor, /window\.pdfEstudio\.ocrPage/);
assert.match(editor, /Nuevo PDF en blanco/);
assert.match(editor, /595\.28, 841\.89/);
assert.match(html, /i18n-extra\.js/);
assert.ok(fs.existsSync(path.join(root, "app", "flags", "zh.svg")));
assert.ok(fs.existsSync(path.join(root, "app", "flags", "ms.svg")));

console.log("version 1.9.4 smoke test passed");
